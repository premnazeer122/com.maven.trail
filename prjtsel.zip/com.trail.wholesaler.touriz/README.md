# com.trail.wholesaler.touriz
Touriz selenium scripts
